export class Persona{
    contructor(){}
    constructor(nombre:String, apellidos:String){}
    id!: number;
    nombre!: String;
    apellidos!: String;
}